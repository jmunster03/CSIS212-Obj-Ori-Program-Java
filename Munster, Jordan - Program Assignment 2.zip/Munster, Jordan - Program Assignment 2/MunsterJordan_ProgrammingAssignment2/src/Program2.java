//Munster, Jordan
//CSIS 212-001 Fall 2023

import java.util.Scanner;

public class Program2 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Jordan Munster - Programming Assignment #2\n");
        System.out.println("This program calculates payroll for a list of employees");
        System.out.println("---------------------------------------------------------\n\n");

        System.out.println("Enter the number of employees:");
        int numEmployees = input.nextInt();

        // Arrays to store employee information
        String[] employeeNames = new String[numEmployees];
        double[] hourlyWages = new double[numEmployees];
        double[] hoursWorked = new double[numEmployees];

        for (int i = 0; i < numEmployees; i++) {
        	
            // Start Entering Employee Information
            System.out.println("Enter Employee Name (or 'exit' to finish):");
            String name = input.next();

            if (name.equals("exit")) {
                break; // Exit the loop if the user enters "exit"
            }

            System.out.println("Enter hourly wage: $");
            double wage = input.nextDouble();

            System.out.println("Enter Hours Worked:");
            double hours = input.nextDouble();

            // Store employee information in arrays
            employeeNames[i] = name;
            hourlyWages[i] = wage;
            hoursWorked[i] = hours;
        }

        // Calculate and display payroll information
        System.out.println("\nPayroll Information\n");
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------");
        System.out.printf("%-20s%-20s%-20s%-20s%-20s%-20s%n", "Employee Name", "Regular Hours", "Overtime Hours", "Regular Pay", "Overtime Pay", "Total Salary");
        System.out.println("----------------------------------------------------------------------------------------------------------------------------------");

        double totalPayroll = 0;

        for (int i = 0; i < numEmployees; i++) {
            double regularHours = Math.min(hoursWorked[i], 40);
            double overtimeHours = Math.max(hoursWorked[i] - 40, 0);
            double regularPay = regularHours * hourlyWages[i];
            double overtimePay = overtimeHours * (hourlyWages[i] * 1.5);
            double totalSalary = regularPay + overtimePay;

            totalPayroll += totalSalary;

            System.out.printf("%-20s%-20.2f%-20.2f%-20.2f%-20.2f%-20.2f%n",
                    employeeNames[i], regularHours, overtimeHours, regularPay, overtimePay, totalSalary);
        }

        // Display total payroll
        System.out.println("\n------------------");
        System.out.println("Total Payroll: $" + totalPayroll);
        System.out.println("------------------");

        input.close();
    }
}
