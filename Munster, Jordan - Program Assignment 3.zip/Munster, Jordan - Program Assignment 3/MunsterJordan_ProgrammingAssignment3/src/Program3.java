//Munster, Jordan
//CSIS 212-001 Fall 2023

import java.util.Scanner;

public class Program3 {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Jordan Munster - Programming Assignment #3\n");
        System.out.println("This program calculates Gross and Net pay for an employee");
        System.out.println("---------------------------------------------------------\n\n");

        // Start entering employee information
        System.out.println("Enter Employee Name: "); // Prompt for user
        String name = input.next(); // Read employee name from user
        System.out.println("\n");

        System.out.println("Enter the Number of Hours Worked: "); // Prompt for user
        double hours = input.nextDouble(); // Read hours worked from user
        System.out.println("\n");

        System.out.println("Enter Hourly Wage: "); // Prompt for user
        double wage = input.nextDouble(); // Read hourly wage from user
        System.out.println("\n");
        
        System.out.println("------------------------------------------\n"); //Spacer

        // Calculate Gross Pay
        double grossPay = calculateGrossPay(hours, wage);

        // Calculate Net Pay (assuming a fixed tax rate of 20%)
        double netPay = calculateNetPay(grossPay);

        // Display payroll summary using the displayPayroll() method
        displayPayroll(name, hours, grossPay, netPay);
        

        input.close();
    }

    // Calculate Gross Pay
    public static double calculateGrossPay(double hoursWorked, double hourlyWage) {
        return hoursWorked * hourlyWage;
    }

    // Calculate Net Pay (assuming a fixed tax rate of 20%)
    public static double calculateNetPay(double grossPay) {
        double taxRate = 0.20; // 20% tax rate
        return grossPay * (1 - taxRate);
    }
   

    // Display payroll summary
    public static void displayPayroll(String name, double hoursWorked, double grossPay, double netPay) {
        System.out.println("Payroll Summary:");
        System.out.println("Employee Name: " + name);
        System.out.println("Hours Worked: " + hoursWorked);
        System.out.println("Gross Pay: $" + grossPay);
        System.out.println("Net Pay: $" + netPay);
    }
}
