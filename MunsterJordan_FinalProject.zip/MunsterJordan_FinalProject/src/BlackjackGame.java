//Munster, Jordan Final Project
//CSIS 212-001

import java.util.ArrayList;
import java.util.Scanner;

public class BlackjackGame {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Jordan Munster's Final Project for CSIS 212-001");
        System.out.println("Welcome to Blackjack!");
        System.out.println("Note: Ace = 1\n");

        String playAgain = "yes";

        while (playAgain.equals("yes")) {
            playGame(scanner);

            // Ask the user if they want to play again
            System.out.println("Do you want to play again? (yes/no)");

            playAgain = scanner.nextLine().trim().toLowerCase();
        }

        System.out.println("Thanks for playing! Goodbye.");
        scanner.close();
    }

 
    private static void playGame(Scanner scanner) {
    	
        // Create a deck of cards and shuffle it
        DeckOfCards deck = new DeckOfCards();
        deck.shuffle();

        // Deal initial cards to the player and the computer
        ArrayList<Card> playerHand = new ArrayList<>();
        ArrayList<Card> computerHand = new ArrayList<>();

        dealInitialCards(playerHand, deck);
        dealInitialCards(computerHand, deck);

        // Player's turn
        playerTurn(playerHand, deck, scanner);

        // Computer's turn
        computerTurn(computerHand, deck);

        // Determine the winner
        determineWinner(playerHand, computerHand);


        scanner.nextLine();
    }

    private static void dealInitialCards(ArrayList<Card> hand, DeckOfCards deck) {
        hand.add(deck.dealCard());
        hand.add(deck.dealCard());
    }

    private static void playerTurn(ArrayList<Card> playerHand, DeckOfCards deck, Scanner scanner) {
        while (true) {
            System.out.println("Your hand: " + playerHand + " (Total: " + calculateScore(playerHand) + ")");
            System.out.print("Do you want to hit (h) or stand (s)? \n");
            char choice = scanner.next().charAt(0);

            if (choice == 'h') {
                // Hit
                Card newCard = deck.dealCard();
                playerHand.add(newCard);
                System.out.println("You drew: " + newCard);
            } else if (choice == 's') {
                // Stand
                System.out.println("You chose to stand.");
                break;
            } else {
                System.out.println("Invalid choice. Please enter 'h' to hit or 's' to stand.");
            }

            int playerScore = calculateScore(playerHand);
            if (playerScore > 21) {
                System.out.println("Bust! Your score is over 21.");
                break;
            } else if (playerScore == 21) {
                System.out.println("You have Blackjack!");
                break;
            }
        }
    }


    private static void computerTurn(ArrayList<Card> computerHand, DeckOfCards deck) {
        // Computer's strategy: Draw cards until the total is at least 17
        while (calculateScore(computerHand) < 17) {
            computerHand.add(deck.dealCard());
        }
    }

    private static int calculateScore(ArrayList<Card> hand) {
        int score = 0;
        int numAces = 0;

        for (Card card : hand) {
            int cardValue = Math.min(10, card.getValueAsNumber()); // Face cards are worth 10
            score += cardValue;

            if (card.getValue().equals("Ace")) {
                numAces++;
            }
        }

        // Handle Aces
        while (numAces > 0 && score > 21) {
            score = 11;
            numAces--;
        }

        return score;
    }

    
    private static void determineWinner(ArrayList<Card> playerHand, ArrayList<Card> computerHand) {
        int playerScore = calculateScore(playerHand);
        int computerScore = calculateScore(computerHand);

        System.out.println("Your hand: " + playerHand + " (Total: " + playerScore + ")");
        System.out.println("Computer's hand: " + computerHand + " (Total: " + computerScore + ")");

        if (playerScore > 21) {
            System.out.println("You lose. Your hand exceeds 21.");
        } else if (computerScore > 21 || playerScore > computerScore) {
            System.out.println("You win!");
        } else if (playerScore < computerScore) {
            System.out.println("You lose. Computer has a higher score.");
        } else {
            System.out.println("It's a tie!");
        }
    }
    
}
