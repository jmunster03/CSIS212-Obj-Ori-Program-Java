//Munster, Jordan Programming Assignment 4
//CSIS 212-001 Fall 2023

public class Rectangle {
    private double length;
    private double width;

    // Constructor with default values
    public Rectangle() {
        length = 1.0;
        width = 1.0;
    }

    // Getter and setter methods for length
    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        if (length > 0.0 && length < 20.0) {
            this.length = length;
        } else {
            System.out.println("Invalid length value. Length must be between 0.0 and 20.0");
        }
    }

    // Getter and setter methods for width
    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        if (width > 0.0 && width < 20.0) {
            this.width = width;
        } else {
            System.out.println("Invalid width value. Width must be between 0.0 and 20.0");
        }
    }

    // Method to calculate the perimeter
    public double calculatePerimeter() {
        return 2 * (length + width);
    }

    // Method to calculate the area
    public double calculateArea() {
        return length * width;
    }
}



