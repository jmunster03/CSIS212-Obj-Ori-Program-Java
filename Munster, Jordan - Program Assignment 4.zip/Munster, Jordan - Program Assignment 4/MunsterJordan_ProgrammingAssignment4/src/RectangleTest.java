//Munster, Jordan Programming Assignment 4
//CSIS 212-001 Fall 2023

import java.util.InputMismatchException;
import java.util.Scanner;

public class RectangleTest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Rectangle rectangle = new Rectangle();
        
        System.out.println("Jordan Munster - Programming Assignment #4\n");
        System.out.println("This program calculates the length, width, perimeter and area of a rectangle");
        System.out.println("----------------------------------------------------------------------------\n\n");

        int choice;
        do {
            System.out.println("Menu:"); //Present menu
            System.out.println("1. Set Length");
            System.out.println("2. Set Width");
            System.out.println("3. Print Perimeter");
            System.out.println("4. Print Area");
            System.out.println("5. Exit \n");
            System.out.print("Enter your choice: ");

            choice = scanner.nextInt();

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter length: ");
                        double newLength = scanner.nextDouble();
                        rectangle.setLength(newLength);
                        System.out.print("\n");
                        break;
                    case 2:
                        System.out.print("Enter width: ");
                        double newWidth = scanner.nextDouble();
                        rectangle.setWidth(newWidth);
                        System.out.print("\n");
                        break;
                    case 3:
                        System.out.println("Perimeter: " + rectangle.calculatePerimeter());
                        System.out.print("\n");
                        break;
                    case 4:
                        System.out.println("Area: " + rectangle.calculateArea());
                        System.out.print("\n");
                        break;
                    case 5:
                        System.out.println("Exiting the program.");
                        break;
                    default:
                        System.out.println("Invalid choice. Please choose a valid option.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid number.");
                scanner.nextLine(); // Consume the invalid input
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        } while (choice != 5);

        scanner.close();
    }
}
