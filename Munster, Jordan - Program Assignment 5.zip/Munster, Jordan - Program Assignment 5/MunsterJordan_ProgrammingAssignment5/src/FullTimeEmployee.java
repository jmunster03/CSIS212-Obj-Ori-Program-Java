public class FullTimeEmployee extends Employee {
    // Additional attribute
    private double annualBonus;

    // Constructor
    public FullTimeEmployee(String name, int employeeID, double salary, double annualBonus) {
        super(name, employeeID, salary); // Call the constructor of the base class
        this.annualBonus = annualBonus;
    }

    // Override displayInfo method
    @Override
    public void displayInfo() {
        super.displayInfo(); // Call the displayInfo method of the base class
        System.out.println("Annual Bonus: $" + annualBonus);
    }

    // Getter method for annualBonus
    public double getAnnualBonus() {
        return annualBonus;
    }

    // Setter method for annualBonus
    public void setAnnualBonus(double annualBonus) {
        this.annualBonus = annualBonus;
    }
}
