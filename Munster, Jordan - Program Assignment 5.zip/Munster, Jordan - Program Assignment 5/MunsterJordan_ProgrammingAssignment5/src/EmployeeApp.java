    public class EmployeeApp {
        public static void main(String[] args) {
            System.out.println("Jordan Munster, Programming Assignment 5\n");

            // Create a FullTimeEmployee and a PartTimeEmployee
            FullTimeEmployee fullTimeEmployee = new FullTimeEmployee("John Doe", 101, 60000.0, 5000.0);
            PartTimeEmployee partTimeEmployee = new PartTimeEmployee("Jane Smith", 102, 20.0, 30);

            // Display information for both employees
            System.out.println("Full-Time Employee Information:");
            fullTimeEmployee.displayInfo();

            System.out.println("\nPart-Time Employee Information:");
            partTimeEmployee.displayInfo();
        }
    }