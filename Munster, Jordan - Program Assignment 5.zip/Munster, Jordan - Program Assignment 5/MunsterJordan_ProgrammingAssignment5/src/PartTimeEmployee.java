public class PartTimeEmployee extends Employee {
    // Additional attribute
    private int hoursWorked;

    // Constructor
    public PartTimeEmployee(String name, int employeeID, double salary, int hoursWorked) {
        super(name, employeeID, salary); // Call the constructor of the base class
        this.hoursWorked = hoursWorked;
    }

    // Override displayInfo method
    @Override
    public void displayInfo() {
        super.displayInfo(); // Call the displayInfo method of the base class
        System.out.println("Hours Worked: " + hoursWorked + " hours");
    }

    // Getter method for hoursWorked
    public int getHoursWorked() {
        return hoursWorked;
    }

    // Setter method for hoursWorked
    public void setHoursWorked(int hoursWorked) {
        this.hoursWorked = hoursWorked;
    }
}
