//Munster, Jordan
//CSIS 212-001 Fall 2023

import java.util.Scanner;
public class Program1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	Scanner input = new Scanner(System.in);
	
	
	System.out.println("Jordan Munster - Programming Assignment #1\n"); 
	System.out.println("This program displays integers and the sums of different equations with those integers");
	System.out.println("-------------------------------------------------------------------------------------------\n\n");
	
	
	//Start entering integers
	System.out.println("Enter First Integer: "); //Prompt for user
	int number1 = input.nextInt(); //Read first number from user
	System.out.print("\n");
	
	System.out.println("Enter Second Integer: "); //Prompt for user
	int number2 = input.nextInt(); //Read second number from user
	System.out.print("\n");
	
	System.out.println("Enter Third Integer: "); //Prompt for user
	int number3 = input.nextInt(); //Read third number from user
	System.out.print("\n");
	
	System.out.println("Enter Fourth Integer: "); //Prompt for user
	int number4 = input.nextInt(); //Read fourth number from user
	System.out.print("\n");
	
	
	System.out.println("------------------------------------------\n"); //spacer
	
	
	//Result for i1+i1+i3+i4
	int sum = number1 + number2 + number3 + number4;
	System.out.printf("The sum is %d%n\n", sum); //display sum
	
	//Result for i1*i2-i3*i4
	int result2 = number1*number2-number3*number4;
	System.out.printf("The result of i1*i2-i3*i4 is %d%n\n", result2); //display result2
	
	//Result for i1*(i2+i3)*i4
	int result3 = number1*(number2+number3)*number4;
	System.out.printf("The result of i1*(i2+i3)*i4 is %d%n\n", result3); //display result3
	
	//Result for (i1+i2+i3+i4)%i1
	int result4 = (number1+number2+number3+number4)%number1;
	System.out.printf("The result of (i1+i2+i3+i4modi1) is %d%n\n", result4); //display result4
	
	
	System.out.println("---------------------------------------------\n"); //spacer
	
	
	//Output lesser of i1 and i2
	int lesser = Math.min(number1, number2); //Output the lesser of number1 and number2
	System.out.printf("The lesser of %d and %d is %d%n", number1, number2, lesser);
	
	//Output the greater of i1+i2 and i3*i4
	int sum2 = number1 + number2;
	int product = number3*number4;
	int greater = Math.max(sum, product);
	System.out.printf("The greater of (%d + %d) and (%d * %d) is %d%n", number1, number2, number3, number4, greater);
	
	System.out.println("--------------------------------------------\n"); //spacer
	
	//Multiples
	 if (number1 % number2 == 0) {
         System.out.printf("%d is a multiple of %d%n", number1, number2);
     } else if (number1 % number3 == 0) {
         System.out.printf("%d is a multiple of %d%n", number1, number3);
     } else if (number1 % number4 == 0) {
         System.out.printf("%d is a multiple of %d%n", number1, number4);
     } else {
         System.out.printf("%d is not a multiple of %d, %d, or %d%n", number1, number2, number3, number4);
     }
	
	
	}

}
