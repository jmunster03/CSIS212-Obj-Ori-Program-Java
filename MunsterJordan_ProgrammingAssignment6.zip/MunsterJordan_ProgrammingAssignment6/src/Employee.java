// Employee class with references to other objects.
public class Employee {
    private String firstName;
    private String lastName;
    private Date birthDate;
    private Date hireDate;

    // constructor to initialize name, birth date, and hire date
    public Employee(String firstName, String lastName, Date birthDate, Date hireDate) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.birthDate = birthDate;
        this.hireDate = hireDate;
    }

    // constructor with default date for birthDate and hireDate
    public Employee(String firstName, String lastName, String socialSecurityNumber, Date birthDate, Date hireDate) {
        this(firstName, lastName, new Date(), new Date()); // default dates if none are provided
    }

    // Get method for birthdate
    public Date getBirthDate() {
        return birthDate;
    }

    // Get method for hire date
    public Date getHireDate() {
        return hireDate;
    }

    // convert Employee to String format
    public String toString() {
        return String.format("%s, %s  Hired: %s  Birthday: %s",
                lastName, firstName, hireDate, birthDate);
    }

    // Method to calculate earnings (to be implemented in subclasses)
    public double earnings() {
        // Implement earnings calculation
        return 0.0;
    }
}
