// Date class declaration.
public class Date {
    private int month; // 1-12
    private int day; // 1-31 based on month
    private int year; // any year

    private static final int[] daysPerMonth = 
        {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    // constructor: confirm proper value for month and day given the year
    public Date(int month, int day, int year) {
        setMonth(month);
        setYear(year);
        setDay(day);
    }

    // constructor for default date
    public Date() {
        this(1, 1, 2000); // default date if none is provided
    }

    // return a String of the form month/day/year
    public String toString() {
        return String.format("%d/%d/%d", month, day, year); 
    }

    // set month
    public void setMonth(int month) {
        if (month <= 0 || month > 12) {
            throw new IllegalArgumentException("month (" + month + ") must be 1-12");
        }
        this.month = month;
    }

    // set day
    public void setDay(int day) {
        if (day <= 0 || (day > daysPerMonth[month] && !(month == 2 && day == 29))) {
            throw new IllegalArgumentException("day (" + day + ") out-of-range for the specified month and year");
        }
        this.day = day;
    }

    // set year
    public void setYear(int year) {
        if (year < 0) {
            throw new IllegalArgumentException("year (" + year + ") must be a positive integer");
        }
        this.year = year;
    }

    // get month
    public int getMonth() {
        return month; 
    }
}
